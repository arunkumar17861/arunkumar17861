/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { HeightCanvas } from './components/HeightCanvas';
import { SubjectsList } from './components/SubjectsList';
import { ComparisonInsights } from './components/ComparisonInsights';
import { ExampleLineups } from './components/ExampleLineups';
import { EducationalSection } from './components/EducationalSection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';

import { AddPersonModal } from './components/AddPersonModal';
import { PresetLibraryModal } from './components/PresetLibraryModal';
import { ShareExportModal } from './components/ShareExportModal';
import { SavedComparisonsModal } from './components/SavedComparisonsModal';

import { ComparisonSubject, CanvasSettings, SavedComparison } from './types';
import { decodeComparisonFromUrl } from './utils/urlSharing';
import { SAMPLE_LINEUPS } from './data/presets';
import { runMeasurementUnitTests } from './utils/measurement.test';

const DEFAULT_SUBJECTS: ComparisonSubject[] = [
  {
    id: 'default_male',
    name: 'Adult Male',
    heightCm: 178,
    category: 'person',
    genderStyle: 'male',
    color: '#3b82f6',
    isVisible: true,
  },
  {
    id: 'default_female',
    name: 'Adult Female',
    heightCm: 165,
    category: 'person',
    genderStyle: 'female',
    color: '#ec4899',
    isVisible: true,
  },
  {
    id: 'default_fridge',
    name: 'Refrigerator',
    heightCm: 175,
    category: 'object',
    objectPresetKey: 'refrigerator',
    color: '#94a3b8',
    isVisible: true,
  },
  {
    id: 'default_bball',
    name: 'Basketball Player',
    heightCm: 198,
    category: 'person',
    genderStyle: 'athletic_male',
    color: '#eab308',
    isVisible: true,
  },
];

const DEFAULT_SETTINGS: CanvasSettings = {
  showGrid: true,
  showRulerLeft: true,
  showRulerRight: true,
  showHeightLabels: true,
  showNameLabels: true,
  showGroundLine: true,
  rulerUnit: 'dual',
  background: 'neutral',
  zoom: 1,
  panOffset: 0,
};

export default function App() {
  // Theme state
  const [isDark, setIsDark] = useState<boolean>(() => {
    const saved = localStorage.getItem('height_studio_theme');
    if (saved) return saved === 'dark';
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  // Apply dark mode class to html document
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('height_studio_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('height_studio_theme', 'light');
    }
  }, [isDark]);

  // Run measurement engine unit tests once on mount to verify mathematical integrity
  useEffect(() => {
    const testResults = runMeasurementUnitTests();
    if (testResults.failed > 0) {
      console.error('Measurement unit test failure:', testResults.results);
    } else {
      console.log(`[Height Studio] Measurement engine validated: ${testResults.passed}/${testResults.total} tests passed.`);
    }
  }, []);

  // Comparison state with Undo/Redo history stack
  const [history, setHistory] = useState<ComparisonSubject[][]>(() => {
    const urlRestored = decodeComparisonFromUrl();
    return [urlRestored || DEFAULT_SUBJECTS];
  });
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  const subjects = history[historyIndex] || DEFAULT_SUBJECTS;

  const pushState = useCallback((newSubjects: ComparisonSubject[]) => {
    setHistory((prev) => {
      const sliced = prev.slice(0, historyIndex + 1);
      return [...sliced, newSubjects];
    });
    setHistoryIndex((prev) => prev + 1);
  }, [historyIndex]);

  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      setHistoryIndex((prev) => prev - 1);
    }
  }, [historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex((prev) => prev + 1);
    }
  }, [historyIndex, history.length]);

  // Keyboard shortcut listener for Ctrl+Z (Undo) and Ctrl+Y (Redo)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'z') {
        if (e.shiftKey) {
          e.preventDefault();
          handleRedo();
        } else {
          e.preventDefault();
          handleUndo();
        }
      } else if ((e.metaKey || e.ctrlKey) && e.key === 'y') {
        e.preventDefault();
        handleRedo();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo]);

  // Canvas Settings
  const [settings, setSettings] = useState<CanvasSettings>(DEFAULT_SETTINGS);

  const handleUpdateSettings = (newSettings: Partial<CanvasSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Modals state
  const [isAddPersonOpen, setIsAddPersonOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<ComparisonSubject | null>(null);
  const [isPresetsOpen, setIsPresetsOpen] = useState(false);
  const [isShareExportOpen, setIsShareExportOpen] = useState(false);
  const [isSavedModalOpen, setIsSavedModalOpen] = useState(false);

  // Active lineup tracker
  const [activeLineupId, setActiveLineupId] = useState<string | undefined>('average_worldwide');

  // Saved comparisons in localStorage
  const [savedComparisons, setSavedComparisons] = useState<SavedComparison[]>(() => {
    try {
      const raw = localStorage.getItem('height_studio_saved');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const handleSaveToLocalStorage = (title: string) => {
    const newSaved: SavedComparison = {
      id: `saved_${Date.now()}`,
      title,
      savedAt: Date.now(),
      subjects,
    };
    const updated = [newSaved, ...savedComparisons];
    setSavedComparisons(updated);
    localStorage.setItem('height_studio_saved', JSON.stringify(updated));
  };

  const handleDeleteSaved = (id: string) => {
    const updated = savedComparisons.filter((s) => s.id !== id);
    setSavedComparisons(updated);
    localStorage.setItem('height_studio_saved', JSON.stringify(updated));
  };

  // Subject Actions
  const handleSaveSubject = (savedSubject: ComparisonSubject) => {
    const existingIndex = subjects.findIndex((s) => s.id === savedSubject.id);
    if (existingIndex >= 0) {
      // Edit existing
      const next = [...subjects];
      next[existingIndex] = savedSubject;
      pushState(next);
    } else {
      // Add new
      pushState([...subjects, savedSubject]);
    }
    setEditingSubject(null);
  };

  const handleAddPresetSubject = (newSubject: ComparisonSubject) => {
    pushState([...subjects, newSubject]);
  };

  const handleEditSubject = (subject: ComparisonSubject) => {
    setEditingSubject(subject);
    setIsAddPersonOpen(true);
  };

  const handleDuplicateSubject = (subject: ComparisonSubject) => {
    const duplicated: ComparisonSubject = {
      ...subject,
      id: `${subject.id}_copy_${Date.now()}`,
      name: `${subject.name} (Copy)`,
    };
    pushState([...subjects, duplicated]);
  };

  const handleToggleSubjectVisibility = (id: string) => {
    const next = subjects.map((s) => (s.id === id ? { ...s, isVisible: !s.isVisible } : s));
    pushState(next);
  };

  const handleDeleteSubject = (id: string) => {
    const next = subjects.filter((s) => s.id !== id);
    pushState(next);
  };

  const handleMoveSubject = (id: string, direction: 'left' | 'right' | 'up' | 'down') => {
    const index = subjects.findIndex((s) => s.id === id);
    if (index === -1) return;

    const targetIndex = direction === 'left' || direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= subjects.length) return;

    const next = [...subjects];
    const [moved] = next.splice(index, 1);
    next.splice(targetIndex, 0, moved);
    pushState(next);
  };

  const handleResetAll = () => {
    pushState([]);
    setActiveLineupId(undefined);
  };

  const handleLoadLineup = (lineupId: string) => {
    const lineup = SAMPLE_LINEUPS.find((l) => l.id === lineupId);
    if (lineup) {
      pushState(lineup.subjects);
      setActiveLineupId(lineupId);
    }
  };

  const handleLoadSavedComparison = (saved: SavedComparison) => {
    pushState(saved.subjects);
    setActiveLineupId(undefined);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 selection:bg-indigo-500 selection:text-white">
      {/* Navigation Bar */}
      <Navbar
        isDark={isDark}
        onToggleTheme={() => setIsDark((prev) => !prev)}
        onOpenShare={() => setIsShareExportOpen(true)}
        onOpenExport={() => setIsShareExportOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 py-6 space-y-8">
        {/* Workspace Toolbar (Undo/Redo & Quick Actions) */}
        <section id="workspace" className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Visual Height Comparison
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              Accurately proportioned shared baseline scaling for humans, animals, objects, and landmarks.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Undo / Redo */}
            <div className="flex items-center rounded-lg border border-slate-200 bg-white p-0.5 shadow-2xs dark:border-slate-800 dark:bg-slate-900">
              <button
                disabled={historyIndex <= 0}
                onClick={handleUndo}
                className="px-2.5 py-1 text-xs font-semibold text-slate-600 disabled:opacity-30 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 rounded transition-colors"
                title="Undo (Ctrl+Z)"
              >
                Undo
              </button>
              <button
                disabled={historyIndex >= history.length - 1}
                onClick={handleRedo}
                className="px-2.5 py-1 text-xs font-semibold text-slate-600 disabled:opacity-30 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 rounded transition-colors"
                title="Redo (Ctrl+Y)"
              >
                Redo
              </button>
            </div>

            {/* Saved Library */}
            <button
              onClick={() => setIsSavedModalOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 shadow-2xs hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 transition-colors"
            >
              Saved ({savedComparisons.length})
            </button>
          </div>
        </section>

        {/* Workspace Split Layout: Active Subjects Sidebar & Interactive Canvas */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Sidebar: Lineup Controls (lg: 4 cols) */}
          <div className="lg:col-span-4 h-[580px]">
            <SubjectsList
              subjects={subjects}
              onOpenAddPerson={() => {
                setEditingSubject(null);
                setIsAddPersonOpen(true);
              }}
              onOpenPresets={() => setIsPresetsOpen(true)}
              onEditSubject={handleEditSubject}
              onDuplicateSubject={handleDuplicateSubject}
              onToggleVisibility={handleToggleSubjectVisibility}
              onDeleteSubject={handleDeleteSubject}
              onMoveSubject={(id, dir) => handleMoveSubject(id, dir)}
              onResetAll={handleResetAll}
            />
          </div>

          {/* Right Main Canvas: (lg: 8 cols) */}
          <div className="lg:col-span-8 flex flex-col">
            <HeightCanvas
              subjects={subjects}
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              onEditSubject={handleEditSubject}
              onDuplicateSubject={handleDuplicateSubject}
              onToggleSubjectVisibility={handleToggleSubjectVisibility}
              onDeleteSubject={handleDeleteSubject}
              onMoveSubject={(id, dir) => handleMoveSubject(id, dir)}
              onOpenAddPerson={() => {
                setEditingSubject(null);
                setIsAddPersonOpen(true);
              }}
              onOpenPresets={() => setIsPresetsOpen(true)}
              onLoadLineup={handleLoadLineup}
            />
          </div>
        </div>

        {/* Section 4: Comparison Insights & Pairwise Statistics */}
        <ComparisonInsights subjects={subjects} />

        {/* Section 5: Curated Example Lineups */}
        <ExampleLineups
          onLoadLineup={handleLoadLineup}
          activeLineupId={activeLineupId}
        />

        {/* Section 6: Science & Educational Guide */}
        <EducationalSection />

        {/* Section 7: FAQ Accordion */}
        <FaqSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals */}
      <AddPersonModal
        isOpen={isAddPersonOpen}
        onClose={() => {
          setIsAddPersonOpen(false);
          setEditingSubject(null);
        }}
        onSave={handleSaveSubject}
        initialSubject={editingSubject}
      />

      <PresetLibraryModal
        isOpen={isPresetsOpen}
        onClose={() => setIsPresetsOpen(false)}
        onAddPreset={handleAddPresetSubject}
      />

      <ShareExportModal
        isOpen={isShareExportOpen}
        onClose={() => setIsShareExportOpen(false)}
        subjects={subjects}
        isDark={isDark}
        onSaveToLocalStorage={handleSaveToLocalStorage}
      />

      <SavedComparisonsModal
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        savedList={savedComparisons}
        onLoadComparison={handleLoadSavedComparison}
        onDeleteSaved={handleDeleteSaved}
      />
    </div>
  );
}
