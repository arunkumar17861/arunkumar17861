/**
 * Unit tests for Height Studio measurement engine.
 * Covers exact conversions, rounding, scale math, and edge cases.
 */
import {
  cmToM,
  mToCm,
  cmToTotalInches,
  totalInchesToCm,
  cmToFeetAndInches,
  feetAndInchesToCm,
  formatHeight,
  formatBothUnits,
  calculatePairwiseDifference,
  calculateComparisonStats,
  validateHeight,
  CM_PER_INCH,
  CM_PER_FOOT,
} from './measurement';
import { ComparisonSubject } from '../types';

export function runMeasurementUnitTests(): {
  total: number;
  passed: number;
  failed: number;
  results: { testName: string; passed: boolean; message?: string }[];
} {
  const tests: { name: string; fn: () => void }[] = [];
  const results: { testName: string; passed: boolean; message?: string }[] = [];

  function assert(condition: boolean, msg: string) {
    if (!condition) throw new Error(msg);
  }

  function assertEqual(actual: unknown, expected: unknown, msg: string) {
    if (actual !== expected) {
      throw new Error(`${msg}: expected ${expected}, got ${actual}`);
    }
  }

  function assertClose(actual: number, expected: number, delta: number = 0.01, msg: string) {
    if (Math.abs(actual - expected) > delta) {
      throw new Error(`${msg}: expected close to ${expected}, got ${actual}`);
    }
  }

  // 1. Exact Conversion Constants
  tests.push({
    name: 'Constants are mathematically exact',
    fn: () => {
      assertEqual(CM_PER_INCH, 2.54, '1 inch must equal 2.54 cm');
      assertEqual(CM_PER_FOOT, 30.48, '1 foot must equal 30.48 cm');
    },
  });

  // 2. Metric Conversions
  tests.push({
    name: 'Metric conversions (cm <-> m)',
    fn: () => {
      assertEqual(cmToM(175), 1.75, '175 cm should be 1.75 m');
      assertEqual(mToCm(1.85), 185, '1.85 m should be 185 cm');
      assertEqual(cmToM(0), 0, '0 cm should be 0 m');
    },
  });

  // 3. Imperial Conversions
  tests.push({
    name: 'Imperial conversions (cm <-> inches)',
    fn: () => {
      assertEqual(totalInchesToCm(10), 25.4, '10 inches should be 25.4 cm');
      assertClose(cmToTotalInches(25.4), 10, 0.05, '25.4 cm should be 10 inches');
    },
  });

  // 4. Feet & Inches calculations
  tests.push({
    name: 'Feet and inches exact conversion and rounding',
    fn: () => {
      // 182.88 cm is exactly 6 feet (72 inches)
      const sixFeet = cmToFeetAndInches(182.88);
      assertEqual(sixFeet.feet, 6, '182.88 cm should be 6 feet');
      assertEqual(sixFeet.inches, 0, '182.88 cm should have 0 inches');
      assertEqual(sixFeet.formatted, `6' 0"`, 'Formatted string for 6 feet');

      // 175 cm is ~5' 8.9"
      const person175 = cmToFeetAndInches(175);
      assertEqual(person175.feet, 5, '175 cm feet');
      assertEqual(person175.inches, 8.9, '175 cm inches');
      assertEqual(person175.formatted, `5' 8.9"`, '175 cm formatted');

      // Inverse: 5' 9" to cm
      const backCm = feetAndInchesToCm(5, 9);
      assertEqual(backCm, 175.3, '5 ft 9 in should be 175.3 cm');
    },
  });

  // 5. Edge cases: 11.99 inches rounding up to 12 -> increment foot
  tests.push({
    name: 'Inches edge case rollover to next foot',
    fn: () => {
      // 182.75 cm -> 71.948 inches -> 5 ft 11.9 in.
      // 182.85 cm -> 71.988 inches -> 6 ft 0 in.
      const res = cmToFeetAndInches(182.85);
      assertEqual(res.feet, 6, 'Edge case foot rollover');
      assertEqual(res.inches, 0, 'Rollover inches to 0');
    },
  });

  // 6. Formatting utilities
  tests.push({
    name: 'Height formatting for all unit modes',
    fn: () => {
      assertEqual(formatHeight(175, 'cm'), '175 cm', 'cm format');
      assertEqual(formatHeight(175, 'm'), '1.75 m', 'm format');
      assertEqual(formatHeight(175, 'ft_in'), `5' 8.9"`, 'ft_in format');
      assertEqual(formatHeight(175, 'in'), '68.9"', 'in format');
      assertEqual(formatHeight(0, 'cm'), '0 cm', '0 cm handling');
      assertEqual(formatHeight(-10, 'cm'), '0 cm', 'negative cm handling');
    },
  });

  // 7. Pairwise Difference calculations
  tests.push({
    name: 'Pairwise difference and ratios',
    fn: () => {
      const shaq: ComparisonSubject = {
        id: '1',
        name: "Shaquille O'Neal",
        heightCm: 216,
        category: 'person',
        color: '#3b82f6',
        isVisible: true,
      };
      const kevin: ComparisonSubject = {
        id: '2',
        name: 'Kevin Hart',
        heightCm: 157,
        category: 'person',
        color: '#ef4444',
        isVisible: true,
      };

      const diff = calculatePairwiseDifference(shaq, kevin);
      assertEqual(diff.diffCm, 59, 'Height diff in cm');
      assertEqual(diff.diffInches, 23.2, 'Height diff in inches');
      assertEqual(diff.tallerSubject.name, "Shaquille O'Neal", 'Taller subject identified');
      assertEqual(diff.shorterSubject.name, 'Kevin Hart', 'Shorter subject identified');
      assertEqual(diff.ratio, 1.38, 'Height ratio calculation');
      assertEqual(diff.percentDiff, 37.6, 'Percent taller calculation');
    },
  });

  // 8. Statistics calculation
  tests.push({
    name: 'Summary statistics (Tallest, Shortest, Avg, Range)',
    fn: () => {
      const subjects: ComparisonSubject[] = [
        { id: '1', name: 'A', heightCm: 160, category: 'person', color: '#000', isVisible: true },
        { id: '2', name: 'B', heightCm: 170, category: 'person', color: '#000', isVisible: true },
        { id: '3', name: 'C', heightCm: 180, category: 'person', color: '#000', isVisible: true },
        { id: '4', name: 'Hidden', heightCm: 250, category: 'person', color: '#000', isVisible: false },
      ];

      const stats = calculateComparisonStats(subjects);
      assertEqual(stats.count, 3, 'Only counts visible subjects');
      assertEqual(stats.shortest?.name, 'A', 'Shortest is A');
      assertEqual(stats.tallest?.name, 'C', 'Tallest is C');
      assertEqual(stats.avgCm, 170, 'Average height');
      assertEqual(stats.medianCm, 170, 'Median height');
      assertEqual(stats.rangeCm, 20, 'Range calculation');
    },
  });

  // 9. Input validation
  tests.push({
    name: 'Height input validation',
    fn: () => {
      assertEqual(validateHeight(0).isValid, false, '0 is invalid');
      assertEqual(validateHeight(-50).isValid, false, 'negative is invalid');
      assertEqual(validateHeight(NaN).isValid, false, 'NaN is invalid');
      assertEqual(validateHeight(175).isValid, true, '175 is valid');
      assert(!!validateHeight(300, 'person').warning, 'Warns for human > 275 cm');
      assert(!!validateHeight(30, 'person').warning, 'Warns for human < 45 cm');
    },
  });

  // Execute all tests
  for (const t of tests) {
    try {
      t.fn();
      results.push({ testName: t.name, passed: true });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      results.push({ testName: t.name, passed: false, message });
    }
  }

  const passed = results.filter((r) => r.passed).length;
  const failed = results.length - passed;

  return {
    total: results.length,
    passed,
    failed,
    results,
  };
}
