import { ComparisonSubject, UnitPreference, HeightDifferenceResult } from '../types';

export const CM_PER_INCH = 2.54;
export const INCHES_PER_FOOT = 12;
export const CM_PER_FOOT = CM_PER_INCH * INCHES_PER_FOOT; // 30.48 cm
export const CM_PER_METER = 100;

/**
 * Converts centimeters to meters rounded to 2 decimal places.
 */
export function cmToM(cm: number): number {
  return Number((cm / CM_PER_METER).toFixed(2));
}

/**
 * Converts meters to centimeters.
 */
export function mToCm(meters: number): number {
  return Number((meters * CM_PER_METER).toFixed(1));
}

/**
 * Converts centimeters to total inches.
 */
export function cmToTotalInches(cm: number): number {
  return Number((cm / CM_PER_INCH).toFixed(1));
}

/**
 * Converts total inches to centimeters.
 */
export function totalInchesToCm(inches: number): number {
  return Number((inches * CM_PER_INCH).toFixed(1));
}

/**
 * Converts centimeters to feet and fractional inches.
 */
export function cmToFeetAndInches(cm: number): {
  feet: number;
  inches: number;
  totalInches: number;
  formatted: string;
} {
  if (cm <= 0 || isNaN(cm)) {
    return { feet: 0, inches: 0, totalInches: 0, formatted: `0' 0"` };
  }

  const rawTotalInches = cm / CM_PER_INCH;
  let feet = Math.floor(rawTotalInches / INCHES_PER_FOOT);
  let inches = Number((rawTotalInches % INCHES_PER_FOOT).toFixed(1));

  // If inches rounded up to 12, increment foot
  if (inches >= 12) {
    feet += 1;
    inches = 0;
  }

  // Format with clean apostrophe and quote
  const formattedInches = inches % 1 === 0 ? inches.toFixed(0) : inches.toFixed(1);
  return {
    feet,
    inches,
    totalInches: Number(rawTotalInches.toFixed(1)),
    formatted: `${feet}' ${formattedInches}"`,
  };
}

/**
 * Converts feet and inches to centimeters.
 */
export function feetAndInchesToCm(feet: number, inches: number): number {
  const safeFeet = Math.max(0, isNaN(feet) ? 0 : feet);
  const safeInches = Math.max(0, isNaN(inches) ? 0 : inches);
  const totalInches = safeFeet * INCHES_PER_FOOT + safeInches;
  return Number((totalInches * CM_PER_INCH).toFixed(1));
}

/**
 * Formats a height in centimeters into the chosen unit preference.
 */
export function formatHeight(cm: number, unit: UnitPreference = 'cm'): string {
  if (isNaN(cm) || cm <= 0) return '0 cm';

  switch (unit) {
    case 'm':
      return `${(cm / 100).toFixed(2)} m`;
    case 'in':
      return `${(cm / CM_PER_INCH).toFixed(1)}"`;
    case 'ft_in': {
      const { formatted } = cmToFeetAndInches(cm);
      return formatted;
    }
    case 'cm':
    default:
      return `${Math.round(cm * 10) / 10} cm`;
  }
}

/**
 * Returns formatted height string in both Metric (cm / m) and Imperial (ft' in")
 */
export function formatBothUnits(cm: number): {
  metric: string;
  imperial: string;
  combined: string;
} {
  if (isNaN(cm) || cm <= 0) {
    return { metric: '0 cm', imperial: `0' 0"`, combined: `0 cm (0' 0")` };
  }

  const metric = cm >= 1000 
    ? `${(cm / 100).toFixed(1)} m` 
    : `${Number(cm.toFixed(1))} cm`;

  const imperial = cmToFeetAndInches(cm).formatted;
  return {
    metric,
    imperial,
    combined: `${metric} (${imperial})`,
  };
}

/**
 * Calculates the difference between two subjects.
 */
export function calculatePairwiseDifference(
  subjectA: ComparisonSubject,
  subjectB: ComparisonSubject
): HeightDifferenceResult {
  const isATaller = subjectA.heightCm >= subjectB.heightCm;
  const taller = isATaller ? subjectA : subjectB;
  const shorter = isATaller ? subjectB : subjectA;

  const diffCm = Number((taller.heightCm - shorter.heightCm).toFixed(1));
  const diffInches = Number((diffCm / CM_PER_INCH).toFixed(1));
  const diffFeetIn = cmToFeetAndInches(diffCm).formatted;

  const ratio = shorter.heightCm > 0 
    ? Number((taller.heightCm / shorter.heightCm).toFixed(2)) 
    : 1;

  const percentDiff = shorter.heightCm > 0 
    ? Number((((taller.heightCm - shorter.heightCm) / shorter.heightCm) * 100).toFixed(1)) 
    : 0;

  return {
    diffCm,
    diffInches,
    diffFeetIn,
    ratio,
    percentDiff,
    tallerSubject: taller,
    shorterSubject: shorter,
  };
}

/**
 * Computes descriptive statistics for a list of comparison subjects.
 */
export function calculateComparisonStats(subjects: ComparisonSubject[]) {
  const visible = subjects.filter((s) => s.isVisible && s.heightCm > 0);

  if (visible.length === 0) {
    return {
      count: 0,
      tallest: null,
      shortest: null,
      avgCm: 0,
      medianCm: 0,
      rangeCm: 0,
    };
  }

  // Sort ascending by height
  const sorted = [...visible].sort((a, b) => a.heightCm - b.heightCm);
  const shortest = sorted[0];
  const tallest = sorted[sorted.length - 1];

  const total = sorted.reduce((acc, curr) => acc + curr.heightCm, 0);
  const avgCm = Number((total / sorted.length).toFixed(1));

  // Median
  const mid = Math.floor(sorted.length / 2);
  const medianCm = sorted.length % 2 === 0
    ? Number(((sorted[mid - 1].heightCm + sorted[mid].heightCm) / 2).toFixed(1))
    : sorted[mid].heightCm;

  const rangeCm = Number((tallest.heightCm - shortest.heightCm).toFixed(1));

  return {
    count: visible.length,
    tallest,
    shortest,
    avgCm,
    medianCm,
    rangeCm,
  };
}

/**
 * Validates height input.
 */
export function validateHeight(cm: number, category: string = 'person'): {
  isValid: boolean;
  warning?: string;
  error?: string;
} {
  if (isNaN(cm) || cm <= 0) {
    return { isValid: false, error: 'Height must be a positive number greater than 0.' };
  }

  if (cm > 100000) {
    return { isValid: false, error: 'Height exceeds maximum supported limit (1,000 meters).' };
  }

  if (category === 'person') {
    if (cm < 45) {
      return { 
        isValid: true, 
        warning: 'This is unusually small for a human (newborn average is ~50 cm, shortest recorded adult Chandra Dangi was 54.6 cm).' 
      };
    }
    if (cm > 275) {
      return { 
        isValid: true, 
        warning: 'This exceeds the tallest recorded human in history (Robert Wadlow was 272 cm / 8\'11").' 
      };
    }
  }

  return { isValid: true };
}
