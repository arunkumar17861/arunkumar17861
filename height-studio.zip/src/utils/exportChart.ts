import { ComparisonSubject } from '../types';
import { formatBothUnits, calculateComparisonStats } from './measurement';

/**
 * Downloads the comparison canvas as a high-resolution PNG.
 * Renders an offscreen canvas at 2x resolution with ground line, rulers, figures, and tags.
 */
export async function downloadChartAsPng(
  subjects: ComparisonSubject[],
  isDarkMode: boolean = false,
  fileName: string = 'height-studio-comparison.png'
): Promise<boolean> {
  try {
    const visibleSubjects = subjects.filter((s) => s.isVisible && s.heightCm > 0);
    if (visibleSubjects.length === 0) return false;

    // Canvas dimensions (2x scale for crisp high-DPI output)
    const scale = 2;
    const paddingX = 60 * scale;
    const paddingBottom = 70 * scale;
    const paddingTop = 90 * scale;

    const tallestCm = Math.max(...visibleSubjects.map((s) => s.heightCm), 200);
    const canvasHeightCm = Math.max(tallestCm * 1.15, 220);

    const figureSlotWidth = 140 * scale;
    const rulerWidth = 90 * scale;
    const totalWidth = rulerWidth + paddingX * 2 + visibleSubjects.length * figureSlotWidth;
    const totalHeight = 700 * scale;

    const canvas = document.createElement('canvas');
    canvas.width = totalWidth;
    canvas.height = totalHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return false;

    const groundY = totalHeight - paddingBottom;
    const availableDrawingHeight = groundY - paddingTop;
    const pixelsPerCm = availableDrawingHeight / canvasHeightCm;

    // 1. Background fill
    ctx.fillStyle = isDarkMode ? '#0f172a' : '#ffffff';
    ctx.fillRect(0, 0, totalWidth, totalHeight);

    // Subtle header border / top branding
    ctx.fillStyle = isDarkMode ? '#94a3b8' : '#64748b';
    ctx.font = `600 ${14 * scale}px 'Plus Jakarta Sans', sans-serif`;
    ctx.fillText('HEIGHT STUDIO · COMPARATIVE SCALE', paddingX, 35 * scale);

    // 2. Rulers & Horizontal Grid Lines
    const stepCm = canvasHeightCm > 1000 ? 500 : canvasHeightCm > 500 ? 100 : canvasHeightCm > 300 ? 50 : 25;
    ctx.strokeStyle = isDarkMode ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)';
    ctx.lineWidth = 1 * scale;

    for (let cm = 0; cm <= canvasHeightCm; cm += stepCm) {
      const y = groundY - cm * pixelsPerCm;
      if (y < paddingTop - 20) break;

      // Grid line across chart
      ctx.beginPath();
      ctx.moveTo(rulerWidth, y);
      ctx.lineTo(totalWidth - paddingX, y);
      ctx.stroke();

      // Tick & Label on ruler
      ctx.fillStyle = isDarkMode ? '#64748b' : '#94a3b8';
      ctx.font = `500 ${10 * scale}px 'JetBrains Mono', monospace`;
      const both = formatBothUnits(cm);
      ctx.fillText(`${cm} cm`, paddingX - 10 * scale, y + 4 * scale);
      ctx.fillText(both.imperial, paddingX - 10 * scale, y + 16 * scale);
    }

    // 3. Ground Baseline
    ctx.strokeStyle = isDarkMode ? '#38bdf8' : '#3b82f6';
    ctx.lineWidth = 3 * scale;
    ctx.beginPath();
    ctx.moveTo(rulerWidth - 20 * scale, groundY);
    ctx.lineTo(totalWidth - paddingX + 20 * scale, groundY);
    ctx.stroke();

    ctx.fillStyle = isDarkMode ? '#38bdf8' : '#3b82f6';
    ctx.font = `700 ${10 * scale}px 'Plus Jakarta Sans', sans-serif`;
    ctx.fillText('GROUND BASELINE (0 cm / 0\' 0")', rulerWidth, groundY + 22 * scale);

    // 4. Render Figures
    visibleSubjects.forEach((subject, idx) => {
      const centerX = rulerWidth + paddingX + idx * figureSlotWidth + figureSlotWidth / 2;
      const figureHeightPx = subject.heightCm * pixelsPerCm;
      const figureTopY = groundY - figureHeightPx;
      const figureWidth = Math.min(figureSlotWidth * 0.75, Math.max(35 * scale, figureHeightPx * 0.38));

      // Subject Silhouette / Bar
      ctx.fillStyle = subject.color || '#3b82f6';
      const radius = 6 * scale;

      // Draw stylized representation
      ctx.beginPath();
      // Simple stylized human / object figure representation on canvas
      const x = centerX - figureWidth / 2;
      const y = figureTopY;
      const w = figureWidth;
      const h = figureHeightPx;

      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + w - radius, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
      ctx.fill();

      // Top height badge pill
      const badgeY = figureTopY - 14 * scale;
      const both = formatBothUnits(subject.heightCm);

      ctx.fillStyle = isDarkMode ? '#1e293b' : '#f1f5f9';
      ctx.strokeStyle = isDarkMode ? '#334155' : '#cbd5e1';
      ctx.lineWidth = 1 * scale;
      
      const badgeText = `${both.metric} · ${both.imperial}`;
      ctx.font = `600 ${10 * scale}px 'JetBrains Mono', monospace`;
      const textWidth = ctx.measureText(badgeText).width;
      const badgeW = textWidth + 14 * scale;
      const badgeH = 20 * scale;

      ctx.beginPath();
      ctx.roundRect(centerX - badgeW / 2, badgeY - badgeH, badgeW, badgeH, 4 * scale);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = isDarkMode ? '#f8fafc' : '#0f172a';
      ctx.textAlign = 'center';
      ctx.fillText(badgeText, centerX, badgeY - 6 * scale);

      // Subject name label below baseline
      ctx.fillStyle = isDarkMode ? '#ffffff' : '#0f172a';
      ctx.font = `700 ${12 * scale}px 'Plus Jakarta Sans', sans-serif`;
      ctx.fillText(subject.name, centerX, groundY + 42 * scale);

      // Category / subtitle
      ctx.fillStyle = isDarkMode ? '#94a3b8' : '#64748b';
      ctx.font = `500 ${10 * scale}px 'Plus Jakarta Sans', sans-serif`;
      ctx.fillText(subject.category.toUpperCase(), centerX, groundY + 56 * scale);
      ctx.textAlign = 'left';
    });

    // 5. Watermark Footer
    ctx.textAlign = 'right';
    ctx.fillStyle = isDarkMode ? '#475569' : '#94a3b8';
    ctx.font = `500 ${10 * scale}px 'Plus Jakarta Sans', sans-serif`;
    ctx.fillText('Height Studio · Accurate Proportional Scale', totalWidth - paddingX, totalHeight - 15 * scale);

    // 6. Download Trigger
    const dataUrl = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    return true;
  } catch (err) {
    console.error('Failed to download chart as PNG', err);
    return false;
  }
}

/**
 * Generates natural language summary text of the comparison for clipboard.
 */
export function generateComparisonSummaryText(subjects: ComparisonSubject[]): string {
  const visible = subjects.filter((s) => s.isVisible && s.heightCm > 0);
  if (visible.length === 0) return 'No subjects in current comparison.';

  const stats = calculateComparisonStats(visible);
  const lines: string[] = [
    `📊 Height Studio Comparison Summary (${visible.length} subjects)`,
    '========================================',
  ];

  visible.forEach((s, idx) => {
    const both = formatBothUnits(s.heightCm);
    lines.push(`${idx + 1}. ${s.name}: ${both.combined}`);
  });

  lines.push('----------------------------------------');
  if (stats.tallest && stats.shortest) {
    lines.push(`• Tallest: ${stats.tallest.name} at ${formatBothUnits(stats.tallest.heightCm).combined}`);
    lines.push(`• Shortest: ${stats.shortest.name} at ${formatBothUnits(stats.shortest.heightCm).combined}`);
    lines.push(`• Height Spread: ${formatBothUnits(stats.rangeCm).combined}`);
    lines.push(`• Group Average: ${formatBothUnits(stats.avgCm).combined}`);
  }
  lines.push('========================================');
  lines.push('Generated via Height Studio: https://heightstudio.app');

  return lines.join('\n');
}

/**
 * Triggers standard browser print dialog.
 */
export function triggerChartPrint() {
  window.print();
}
