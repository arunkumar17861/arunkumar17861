import React, { useState, useMemo } from 'react';
import { 
  X, 
  Search, 
  CheckCircle2, 
  Plus, 
  Shapes,
  Info,
  SlidersHorizontal,
  ChevronRight
} from 'lucide-react';
import { PRESET_LIBRARY } from '../data/presets';
import { PresetItem, ComparisonSubject, CustomShapeType } from '../types';
import { formatBothUnits } from '../utils/measurement';

interface PresetLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddPreset: (subject: ComparisonSubject) => void;
}

type FilterCategory = 
  | 'all' 
  | 'celebrity' 
  | 'athlete' 
  | 'historical' 
  | 'fictional' 
  | 'everyday' 
  | 'vehicle' 
  | 'animal' 
  | 'landmark'
  | 'custom_shape';

export const PresetLibraryModal: React.FC<PresetLibraryModalProps> = ({
  isOpen,
  onClose,
  onAddPreset,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<FilterCategory>('all');
  const [sortBy, setSortBy] = useState<'tallest' | 'shortest' | 'name'>('tallest');

  // Custom shape creator state
  const [customShapeType, setCustomShapeType] = useState<CustomShapeType>('rect');
  const [customShapeName, setCustomShapeName] = useState('Custom Block');
  const [customShapeHeight, setCustomShapeHeight] = useState('180');
  const [customShapeColor, setCustomShapeColor] = useState('#6366f1');

  const filteredPresets = useMemo(() => {
    let list = [...PRESET_LIBRARY];

    if (activeCategory !== 'all' && activeCategory !== 'custom_shape') {
      list = list.filter((p) => p.category === activeCategory);
    }

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          (p.tag && p.tag.toLowerCase().includes(q))
      );
    }

    // Sort
    list.sort((a, b) => {
      if (sortBy === 'tallest') return b.heightCm - a.heightCm;
      if (sortBy === 'shortest') return a.heightCm - b.heightCm;
      return a.name.localeCompare(b.name);
    });

    return list;
  }, [searchTerm, activeCategory, sortBy]);

  const handleSelectPreset = (preset: PresetItem) => {
    const subject: ComparisonSubject = {
      id: `preset_${preset.id}_${Date.now()}`,
      name: preset.name,
      heightCm: preset.heightCm,
      category: ['celebrity', 'athlete', 'historical'].includes(preset.category)
        ? 'person'
        : preset.category === 'animal'
        ? 'animal'
        : preset.category === 'landmark'
        ? 'landmark'
        : 'object',
      genderStyle: preset.genderStyle,
      objectPresetKey: preset.objectPresetKey,
      color: preset.defaultColor,
      notes: preset.description,
      source: preset.source,
      isVerified: preset.isVerified,
      isVisible: true,
    };
    onAddPreset(subject);
  };

  const handleAddCustomShape = (e: React.FormEvent) => {
    e.preventDefault();
    const h = parseFloat(customShapeHeight);
    if (isNaN(h) || h <= 0) return;

    const subject: ComparisonSubject = {
      id: `custom_shape_${Date.now()}`,
      name: customShapeName.trim() || 'Custom Shape',
      heightCm: h,
      category: 'custom',
      customShape: customShapeType,
      color: customShapeColor,
      isVisible: true,
    };
    onAddPreset(subject);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        className="relative w-full max-w-4xl max-h-[90vh] flex flex-col rounded-2xl bg-white shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Preset & Object Library
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Verified celebrities, landmarks, animals, vehicles, and everyday items
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Filter & Search Bar */}
        <div className="border-b border-slate-200 px-6 py-3.5 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-800/40 space-y-3">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search celebrity, animal, door, landmark..."
                className="w-full rounded-xl border border-slate-300 bg-white pl-9 pr-3.5 py-2 text-xs text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              />
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-2 shrink-0">
              <SlidersHorizontal className="h-3.5 w-3.5 text-slate-400" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 shadow-xs focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
              >
                <option value="tallest">Tallest First</option>
                <option value="shortest">Shortest First</option>
                <option value="name">Alphabetical</option>
              </select>
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {[
              { id: 'all', label: 'All Items' },
              { id: 'celebrity', label: 'Celebrities' },
              { id: 'athlete', label: 'Athletes' },
              { id: 'historical', label: 'Historical' },
              { id: 'fictional', label: 'Fictional' },
              { id: 'animal', label: 'Animals' },
              { id: 'everyday', label: 'Everyday Objects' },
              { id: 'vehicle', label: 'Vehicles' },
              { id: 'landmark', label: 'Landmarks' },
              { id: 'custom_shape', label: 'Custom Shapes' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as FilterCategory)}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
                  activeCategory === cat.id
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeCategory === 'custom_shape' ? (
            /* Custom geometric shape builder */
            <form onSubmit={handleAddCustomShape} className="max-w-md mx-auto space-y-4 py-4">
              <div className="flex items-center gap-3 p-4 rounded-xl border border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-800/40">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400">
                  <Shapes className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    Custom Geometric Object
                  </h4>
                  <p className="text-xs text-slate-500">
                    Add custom boxes, cylinders, or circles of any height
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Shape Type
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'rect', label: 'Rectangle / Pillar' },
                    { id: 'cylinder', label: 'Cylinder' },
                    { id: 'circle', label: 'Circle / Sphere' },
                  ].map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setCustomShapeType(s.id as CustomShapeType)}
                      className={`p-2.5 rounded-xl border text-xs font-semibold text-center transition-all ${
                        customShapeType === s.id
                          ? 'border-indigo-600 bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300'
                          : 'border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Object Name
                </label>
                <input
                  type="text"
                  value={customShapeName}
                  onChange={(e) => setCustomShapeName(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Height (in cm)
                </label>
                <input
                  type="number"
                  step="1"
                  min="5"
                  max="100000"
                  value={customShapeHeight}
                  onChange={(e) => setCustomShapeHeight(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Color
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={customShapeColor}
                    onChange={(e) => setCustomShapeColor(e.target.value)}
                    className="h-8 w-12 rounded border border-slate-300 cursor-pointer overflow-hidden dark:border-slate-700"
                  />
                  <span className="text-xs font-mono text-slate-500">{customShapeColor}</span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-indigo-600 py-2.5 text-xs font-semibold text-white hover:bg-indigo-700 shadow-sm transition-colors"
              >
                Add Custom Shape to Chart
              </button>
            </form>
          ) : (
            /* Preset grid */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredPresets.map((preset) => {
                const both = formatBothUnits(preset.heightCm);

                return (
                  <div
                    key={preset.id}
                    className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-4 shadow-2xs hover:border-indigo-300 hover:shadow-sm dark:border-slate-800 dark:bg-slate-900/60 transition-all group"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span
                            className="h-3 w-3 rounded-full shrink-0"
                            style={{ backgroundColor: preset.defaultColor }}
                          />
                          <h4 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                            {preset.name}
                          </h4>
                        </div>
                        {preset.isVerified && (
                          <span
                            title="Verified factual measurement"
                            className="text-emerald-500 shrink-0"
                          >
                            <CheckCircle2 className="h-4 w-4" />
                          </span>
                        )}
                      </div>

                      {/* Height tag */}
                      <div className="mt-2 flex items-baseline gap-1.5 font-mono">
                        <span className="text-base font-bold text-slate-900 dark:text-white">
                          {both.metric}
                        </span>
                        <span className="text-xs text-slate-500 dark:text-slate-400">
                          ({both.imperial})
                        </span>
                      </div>

                      {/* Description & Source */}
                      <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                        {preset.description}
                      </p>

                      {preset.source && (
                        <div className="mt-2 flex items-center gap-1 text-[11px] text-slate-400 dark:text-slate-500">
                          <Info className="h-3 w-3 shrink-0" />
                          <span className="truncate">{preset.source}</span>
                        </div>
                      )}
                    </div>

                    {/* Action button */}
                    <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                        {preset.tag || preset.category}
                      </span>
                      <button
                        onClick={() => handleSelectPreset(preset)}
                        className="inline-flex items-center gap-1 rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-indigo-600 hover:text-white dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-indigo-600 dark:hover:text-white transition-colors"
                      >
                        <Plus className="h-3.5 w-3.5" />
                        Add to Chart
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-slate-200 px-6 py-3.5 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 text-xs text-slate-500">
          <span>Found {filteredPresets.length} items</span>
          <button
            onClick={onClose}
            className="rounded-xl px-4 py-2 font-semibold text-slate-700 hover:bg-slate-200/60 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
