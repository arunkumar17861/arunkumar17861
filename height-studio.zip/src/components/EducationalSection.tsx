import React from 'react';
import { BookOpen, Compass, Ruler, Lightbulb, History, Eye } from 'lucide-react';

export const EducationalSection: React.FC = () => {
  return (
    <section id="science" className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400">
            <BookOpen className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              The Science of Height Comparison
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Understanding orthographic projection, historical measurement units, and human anatomy
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Card 1: Orthographic vs Perspective */}
        <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-5 dark:border-slate-800 dark:bg-slate-800/40 space-y-2.5">
          <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
            <Compass className="h-4 w-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
              Orthographic vs. Camera Perspective
            </h4>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            In photographs, who appears taller depends heavily on distance from the lens, focal length, camera tilt, and shoe soles. Height Studio removes all optical foreshortening by projecting every figure orthographically onto an identical flat 2D plane with zero perspective distortion.
          </p>
        </div>

        {/* Card 2: Ground Baseline Discipline */}
        <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-5 dark:border-slate-800 dark:bg-slate-800/40 space-y-2.5">
          <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
            <Ruler className="h-4 w-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
              Common Baseline Alignment
            </h4>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Every subject stands strictly at <code className="font-mono text-indigo-600 dark:text-indigo-400">0.0 cm</code> on the ground line. The vertical scale automatically calculates the ideal ceiling with uniform linear ratios, ensuring a 200 cm human stands at exactly twice the height of a 100 cm child.
          </p>
        </div>

        {/* Card 3: The Napoleon 5'2" Myth */}
        <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-5 dark:border-slate-800 dark:bg-slate-800/40 space-y-2.5">
          <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
            <History className="h-4 w-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
              The Napoleon 5&apos;2&quot; Myth
            </h4>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Napoleon Bonaparte was recorded at his autopsy as 5 pieds 2 pouces (5 feet 2 inches). However, pre-metric French inches (pouces) were 2.71 cm, not the British 2.54 cm! His actual height was 168.4 cm (5&apos; 6.3&quot;), which was slightly above the average French male height of 164 cm in 1815.
          </p>
        </div>

        {/* Card 4: Diurnal Height Variation */}
        <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-5 dark:border-slate-800 dark:bg-slate-800/40 space-y-2.5">
          <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
            <Lightbulb className="h-4 w-4" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
              Daily Height Variation (Diurnal Shift)
            </h4>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Due to gravity compressing the cartilaginous spinal discs during the day, adult humans are typically 1.0 to 2.0 cm (0.5 to 0.8 inches) taller immediately upon waking in the morning than when going to bed at night. Astronauts in microgravity can temporarily grow up to 5 cm (2 inches).
          </p>
        </div>
      </div>
    </section>
  );
};
