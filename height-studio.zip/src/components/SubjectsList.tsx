import React from 'react';
import { 
  Users, 
  Plus, 
  Trash2, 
  Eye, 
  EyeOff, 
  Edit2, 
  Copy, 
  ArrowUp, 
  ArrowDown, 
  Library,
  RotateCcw
} from 'lucide-react';
import { ComparisonSubject } from '../types';
import { formatBothUnits } from '../utils/measurement';

interface SubjectsListProps {
  subjects: ComparisonSubject[];
  onOpenAddPerson: () => void;
  onOpenPresets: () => void;
  onEditSubject: (subject: ComparisonSubject) => void;
  onDuplicateSubject: (subject: ComparisonSubject) => void;
  onToggleVisibility: (id: string) => void;
  onDeleteSubject: (id: string) => void;
  onMoveSubject: (id: string, direction: 'up' | 'down') => void;
  onResetAll: () => void;
}

export const SubjectsList: React.FC<SubjectsListProps> = ({
  subjects,
  onOpenAddPerson,
  onOpenPresets,
  onEditSubject,
  onDuplicateSubject,
  onToggleVisibility,
  onDeleteSubject,
  onMoveSubject,
  onResetAll,
}) => {
  return (
    <div className="flex flex-col h-full rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3.5 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-indigo-600" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Active Lineup ({subjects.length})
          </h3>
        </div>

        {subjects.length > 0 && (
          <button
            onClick={onResetAll}
            className="flex items-center gap-1 text-[11px] font-medium text-slate-500 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-400 transition-colors"
            title="Reset lineup"
          >
            <RotateCcw className="h-3 w-3" />
            Reset
          </button>
        )}
      </div>

      {/* Quick Action Buttons */}
      <div className="grid grid-cols-2 gap-2 p-3 border-b border-slate-200 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-800/40">
        <button
          onClick={onOpenAddPerson}
          className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-indigo-600 px-3 py-2 text-xs font-semibold text-white shadow-xs hover:bg-indigo-700 transition-colors"
        >
          <Plus className="h-3.5 w-3.5" />
          Add Person
        </button>
        <button
          onClick={onOpenPresets}
          className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-xs hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors"
        >
          <Library className="h-3.5 w-3.5" />
          Add Object
        </button>
      </div>

      {/* Subject Items List */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60 p-2 space-y-1">
        {subjects.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-400">
            No figures added yet. Click &quot;Add Person&quot; or choose from the preset library.
          </div>
        ) : (
          subjects.map((subject, index) => {
            const both = formatBothUnits(subject.heightCm);

            return (
              <div
                key={subject.id}
                className={`group flex items-center justify-between gap-2.5 rounded-xl p-2.5 transition-colors ${
                  !subject.isVisible
                    ? 'opacity-50 bg-slate-50/50 dark:bg-slate-800/20'
                    : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                }`}
              >
                {/* Left details */}
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  {/* Color pill / swatch */}
                  <span
                    className="h-3.5 w-3.5 rounded-full shrink-0 shadow-xs"
                    style={{ backgroundColor: subject.color }}
                  />

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {subject.name}
                      </span>
                      <span className="text-[10px] text-slate-400 capitalize shrink-0">
                        ({subject.category})
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                      {both.metric} · {both.imperial}
                    </div>
                  </div>
                </div>

                {/* Right controls */}
                <div className="flex items-center gap-0.5 shrink-0">
                  {/* Reorder Up/Down */}
                  <button
                    disabled={index === 0}
                    onClick={() => onMoveSubject(subject.id, 'up')}
                    className="p-1 rounded text-slate-400 hover:text-slate-700 disabled:opacity-20 dark:hover:text-slate-200"
                    title="Move Up"
                  >
                    <ArrowUp className="h-3.5 w-3.5" />
                  </button>
                  <button
                    disabled={index === subjects.length - 1}
                    onClick={() => onMoveSubject(subject.id, 'down')}
                    className="p-1 rounded text-slate-400 hover:text-slate-700 disabled:opacity-20 dark:hover:text-slate-200"
                    title="Move Down"
                  >
                    <ArrowDown className="h-3.5 w-3.5" />
                  </button>

                  {/* Edit */}
                  <button
                    onClick={() => onEditSubject(subject)}
                    className="p-1 rounded text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400"
                    title="Edit Height & Details"
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                  </button>

                  {/* Duplicate */}
                  <button
                    onClick={() => onDuplicateSubject(subject)}
                    className="p-1 rounded text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400"
                    title="Duplicate Subject"
                  >
                    <Copy className="h-3.5 w-3.5" />
                  </button>

                  {/* Hide/Show */}
                  <button
                    onClick={() => onToggleVisibility(subject.id)}
                    className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                    title={subject.isVisible ? 'Hide from canvas' : 'Show on canvas'}
                  >
                    {subject.isVisible ? (
                      <Eye className="h-3.5 w-3.5" />
                    ) : (
                      <EyeOff className="h-3.5 w-3.5 text-slate-400" />
                    )}
                  </button>

                  {/* Delete */}
                  <button
                    onClick={() => onDeleteSubject(subject.id)}
                    className="p-1 rounded text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                    title="Remove from lineup"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
