import React from 'react';
import { Ruler } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full border-t border-slate-200 bg-white py-10 dark:border-slate-800 dark:bg-slate-950">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand & info */}
          <div className="flex items-center gap-2.5">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-xs">
              <Ruler className="h-3.5 w-3.5" />
            </div>
            <span className="text-sm font-bold text-slate-900 dark:text-white">
              Height Studio
            </span>
            <span className="text-slate-300 dark:text-slate-700">·</span>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Accurate Proportional Comparison Tool
            </span>
          </div>

          {/* Links */}
          <div className="flex items-center gap-6 text-xs text-slate-500 dark:text-slate-400 flex-wrap justify-center">
            <a href="#workspace" className="hover:text-slate-900 dark:hover:text-white transition-colors">
              Workspace
            </a>
            <a href="#presets" className="hover:text-slate-900 dark:hover:text-white transition-colors">
              Preset Library
            </a>
            <a href="#insights" className="hover:text-slate-900 dark:hover:text-white transition-colors">
              Insights
            </a>
            <a href="#science" className="hover:text-slate-900 dark:hover:text-white transition-colors">
              Science
            </a>
            <a href="#faq" className="hover:text-slate-900 dark:hover:text-white transition-colors">
              FAQ
            </a>
          </div>
        </div>

        <div className="mt-8 border-t border-slate-100 pt-6 text-center text-[11px] text-slate-400 dark:border-slate-800/80">
          <p>
            © {new Date().getFullYear()} Height Studio. All measurements calculated using exact mathematical conversion factors (1 in = 2.54 cm). All heights verified with official combines and anatomical records.
          </p>
        </div>
      </div>
    </footer>
  );
};
