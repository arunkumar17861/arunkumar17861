import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Share2, 
  Copy, 
  Check, 
  Printer, 
  FileText, 
  Bookmark, 
  BookmarkCheck,
  Sparkles
} from 'lucide-react';
import { ComparisonSubject } from '../types';
import { encodeComparisonToUrl } from '../utils/urlSharing';
import { 
  downloadChartAsPng, 
  generateComparisonSummaryText, 
  triggerChartPrint 
} from '../utils/exportChart';

interface ShareExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  subjects: ComparisonSubject[];
  isDark: boolean;
  onSaveToLocalStorage: (name: string) => void;
}

export const ShareExportModal: React.FC<ShareExportModalProps> = ({
  isOpen,
  onClose,
  subjects,
  isDark,
  onSaveToLocalStorage,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedSummary, setCopiedSummary] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [saveName, setSaveName] = useState('My Height Comparison');
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const shareUrl = encodeComparisonToUrl(subjects);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      // Fallback
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Height Studio Comparison',
          text: `Check out this proportional height comparison with ${subjects.length} figures!`,
          url: shareUrl,
        });
      } catch (err) {
        // User aborted or unallowed
      }
    } else {
      handleCopyLink();
    }
  };

  const handleCopySummary = async () => {
    try {
      const text = generateComparisonSummaryText(subjects);
      await navigator.clipboard.writeText(text);
      setCopiedSummary(true);
      setTimeout(() => setCopiedSummary(false), 2500);
    } catch {
      // Fallback
    }
  };

  const handleDownloadPng = async () => {
    setIsExporting(true);
    await downloadChartAsPng(subjects, isDark, `height-studio-${Date.now()}.png`);
    setIsExporting(false);
  };

  const handleSaveLocal = () => {
    if (!saveName.trim()) return;
    onSaveToLocalStorage(saveName.trim());
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        className="relative w-full max-w-lg flex flex-col rounded-2xl bg-white shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400">
              <Share2 className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Share & Export Comparison
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Generate high-res PNG image, shareable link, or print layout
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6">
          {/* Shareable Link */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Unique Shareable Link
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="flex-1 rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs text-slate-600 font-mono select-all dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
              />
              <button
                onClick={handleCopyLink}
                className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs hover:bg-indigo-700 transition-colors shrink-0"
              >
                {copiedLink ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {copiedLink ? 'Copied!' : 'Copy'}
              </button>
            </div>
            <p className="mt-1 text-[11px] text-slate-400">
              Anyone with this link will view this exact comparative lineup.
            </p>
          </div>

          {/* Export Options Grid */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            {/* Download PNG */}
            <button
              onClick={handleDownloadPng}
              disabled={isExporting}
              className="flex flex-col items-center justify-center p-4 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-indigo-50 hover:border-indigo-200 dark:border-slate-800 dark:bg-slate-800/40 dark:hover:bg-indigo-950/30 text-center transition-all group"
            >
              <Download className="h-5 w-5 text-indigo-600 mb-2 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                {isExporting ? 'Generating...' : 'Download PNG'}
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5">High-res 2x graphic</span>
            </button>

            {/* Print Friendly */}
            <button
              onClick={() => {
                onClose();
                setTimeout(() => triggerChartPrint(), 200);
              }}
              className="flex flex-col items-center justify-center p-4 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-100 hover:border-slate-300 dark:border-slate-800 dark:bg-slate-800/40 text-center transition-all group"
            >
              <Printer className="h-5 w-5 text-slate-600 dark:text-slate-400 mb-2 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                Print Chart
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5">Optimized print page</span>
            </button>

            {/* Copy Formatted Text */}
            <button
              onClick={handleCopySummary}
              className="flex flex-col items-center justify-center p-4 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-100 hover:border-slate-300 dark:border-slate-800 dark:bg-slate-800/40 text-center transition-all group"
            >
              {copiedSummary ? (
                <Check className="h-5 w-5 text-emerald-600 mb-2" />
              ) : (
                <FileText className="h-5 w-5 text-slate-600 dark:text-slate-400 mb-2 group-hover:scale-110 transition-transform" />
              )}
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                {copiedSummary ? 'Copied Text!' : 'Copy Summary'}
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5">Text for clipboard</span>
            </button>

            {/* Native Share */}
            <button
              onClick={handleNativeShare}
              className="flex flex-col items-center justify-center p-4 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-100 hover:border-slate-300 dark:border-slate-800 dark:bg-slate-800/40 text-center transition-all group"
            >
              <Share2 className="h-5 w-5 text-slate-600 dark:text-slate-400 mb-2 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                Native Share
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5">Mobile & apps share</span>
            </button>
          </div>

          {/* Save to Browser Storage */}
          <div className="border-t border-slate-200 pt-4 dark:border-slate-800">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Bookmark className="h-3.5 w-3.5 text-indigo-600" />
              Save to Browser Library
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={saveName}
                onChange={(e) => setSaveName(e.target.value)}
                placeholder="Comparison title..."
                className="flex-1 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              />
              <button
                onClick={handleSaveLocal}
                className="inline-flex items-center gap-1 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 transition-colors shrink-0"
              >
                {savedSuccess ? <BookmarkCheck className="h-4 w-4 text-emerald-600" /> : null}
                {savedSuccess ? 'Saved!' : 'Save'}
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end border-t border-slate-200 px-6 py-3.5 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
          <button
            onClick={onClose}
            className="rounded-xl px-4 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-200/60 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
