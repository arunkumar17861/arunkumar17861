import React, { useState, useEffect } from 'react';
import { X, User, Upload, AlertCircle, Check, Sparkles } from 'lucide-react';
import { ComparisonSubject, GenderStyle } from '../types';
import { 
  cmToFeetAndInches, 
  feetAndInchesToCm, 
  validateHeight,
  cmToM,
  mToCm
} from '../utils/measurement';
import { SilhouetteRenderer } from '../data/silhouettes';

interface AddPersonModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (subject: ComparisonSubject) => void;
  initialSubject?: ComparisonSubject | null;
}

const COLOR_PALETTE = [
  '#3b82f6', // Blue
  '#6366f1', // Indigo
  '#8b5cf6', // Violet
  '#ec4899', // Pink
  '#f43f5e', // Rose
  '#ef4444', // Red
  '#f97316', // Orange
  '#f59e0b', // Amber
  '#10b981', // Emerald
  '#06b6d4', // Cyan
  '#64748b', // Slate
  '#1e293b', // Dark Slate
];

const GENDER_OPTIONS: { id: GenderStyle; label: string; desc: string }[] = [
  { id: 'male', label: 'Adult Male', desc: 'Standard adult male silhouette' },
  { id: 'female', label: 'Adult Female', desc: 'Standard adult female silhouette' },
  { id: 'athletic_male', label: 'Athletic Male', desc: 'Broad-shouldered athletic build' },
  { id: 'athletic_female', label: 'Athletic Female', desc: 'Toned runner/athletic build' },
  { id: 'teen', label: 'Youth / Teen', desc: 'Youth proportions' },
  { id: 'child', label: 'Child (Age 8)', desc: 'Young child head-to-torso ratio' },
  { id: 'toddler', label: 'Toddler (Age 2)', desc: 'Toddler proportions' },
  { id: 'neutral', label: 'Neutral', desc: 'Clean geometric human outline' },
];

export const AddPersonModal: React.FC<AddPersonModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialSubject,
}) => {
  const isEditing = Boolean(initialSubject);

  const [name, setName] = useState('');
  const [cmInput, setCmInput] = useState<string>('178');
  const [mInput, setMInput] = useState<string>('1.78');
  const [feetInput, setFeetInput] = useState<string>('5');
  const [inchesInput, setInchesInput] = useState<string>('10');
  const [activeUnitTab, setActiveUnitTab] = useState<'cm' | 'ft_in' | 'm'>('cm');

  const [genderStyle, setGenderStyle] = useState<GenderStyle>('male');
  const [color, setColor] = useState('#3b82f6');
  const [customImageUrl, setCustomImageUrl] = useState<string | undefined>(undefined);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [validationWarning, setValidationWarning] = useState<string | null>(null);

  // Initialize form state when opening
  useEffect(() => {
    if (!isOpen) return;

    if (initialSubject) {
      setName(initialSubject.name);
      const cm = initialSubject.heightCm;
      setCmInput(cm.toString());
      setMInput(cmToM(cm).toString());
      const ftIn = cmToFeetAndInches(cm);
      setFeetInput(ftIn.feet.toString());
      setInchesInput(ftIn.inches.toString());
      setGenderStyle(initialSubject.genderStyle || 'male');
      setColor(initialSubject.color || '#3b82f6');
      setCustomImageUrl(initialSubject.customImageUrl);
    } else {
      // Defaults for new person
      setName('Person');
      setCmInput('178');
      setMInput('1.78');
      setFeetInput('5');
      setInchesInput('10');
      setGenderStyle('male');
      setColor('#3b82f6');
      setCustomImageUrl(undefined);
    }
  }, [isOpen, initialSubject]);

  // Handle synchronized unit inputs
  const handleCmChange = (valStr: string) => {
    setCmInput(valStr);
    const num = parseFloat(valStr);
    if (!isNaN(num) && num > 0) {
      setMInput(cmToM(num).toString());
      const ftIn = cmToFeetAndInches(num);
      setFeetInput(ftIn.feet.toString());
      setInchesInput(ftIn.inches.toString());
      validate(num);
    } else {
      setValidationError('Please enter a valid height.');
    }
  };

  const handleMChange = (valStr: string) => {
    setMInput(valStr);
    const num = parseFloat(valStr);
    if (!isNaN(num) && num > 0) {
      const cm = mToCm(num);
      setCmInput(cm.toString());
      const ftIn = cmToFeetAndInches(cm);
      setFeetInput(ftIn.feet.toString());
      setInchesInput(ftIn.inches.toString());
      validate(cm);
    }
  };

  const handleFeetInchesChange = (ftStr: string, inStr: string) => {
    setFeetInput(ftStr);
    setInchesInput(inStr);
    const ft = parseFloat(ftStr) || 0;
    const inch = parseFloat(inStr) || 0;
    const cm = feetAndInchesToCm(ft, inch);
    if (cm > 0) {
      setCmInput(cm.toString());
      setMInput(cmToM(cm).toString());
      validate(cm);
    }
  };

  const validate = (cm: number) => {
    const res = validateHeight(cm, 'person');
    if (!res.isValid) {
      setValidationError(res.error || 'Invalid height');
      setValidationWarning(null);
    } else {
      setValidationError(null);
      setValidationWarning(res.warning || null);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setValidationError('Please upload a valid image file (PNG, WebP, JPEG).');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setCustomImageUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalCm = parseFloat(cmInput);

    if (isNaN(finalCm) || finalCm <= 0) {
      setValidationError('Please enter a valid height greater than 0.');
      return;
    }

    const cleanedName = name.trim() || 'Person';

    const subjectToSave: ComparisonSubject = {
      id: initialSubject ? initialSubject.id : `person_${Date.now()}`,
      name: cleanedName,
      heightCm: Number(finalCm.toFixed(1)),
      category: 'person',
      genderStyle,
      color,
      customImageUrl,
      isVisible: true,
    };

    onSave(subjectToSave);
    onClose();
  };

  // Preview dummy subject
  const previewSubject: ComparisonSubject = {
    id: 'preview',
    name: name || 'Preview',
    heightCm: parseFloat(cmInput) || 178,
    category: 'person',
    genderStyle,
    color,
    customImageUrl,
    isVisible: true,
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        className="relative w-full max-w-xl max-h-[92vh] flex flex-col rounded-2xl bg-white shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400">
              <User className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {isEditing ? 'Edit Person' : 'Add New Person'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Configure silhouette, height, and custom colors
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Live Preview & Name */}
          <div className="flex items-center gap-6 rounded-xl border border-slate-200 bg-slate-50/70 p-4 dark:border-slate-800 dark:bg-slate-800/40">
            <div className="flex h-36 w-28 shrink-0 items-end justify-center rounded-lg border border-slate-200/80 bg-white p-2 dark:border-slate-700 dark:bg-slate-900 relative shadow-xs">
              <div className="h-full w-full flex items-end justify-center">
                <SilhouetteRenderer subject={previewSubject} />
              </div>
              <div className="absolute bottom-0 inset-x-0 h-0.5 bg-indigo-600" />
            </div>
            <div className="flex-1 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Person Name or Label
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. John, Sarah, Me"
                  className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                  required
                />
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                Height: <span className="font-semibold text-slate-900 dark:text-white font-mono">{cmInput} cm</span> ({feetInput}&apos; {inchesInput}&quot;)
              </div>
            </div>
          </div>

          {/* Synchronized Height Input */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Height Measurement
              </label>
              {/* Unit switcher tabs */}
              <div className="flex items-center rounded-lg border border-slate-200 bg-slate-100 p-0.5 dark:border-slate-700 dark:bg-slate-800">
                <button
                  type="button"
                  onClick={() => setActiveUnitTab('cm')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                    activeUnitTab === 'cm'
                      ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                >
                  cm
                </button>
                <button
                  type="button"
                  onClick={() => setActiveUnitTab('ft_in')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                    activeUnitTab === 'ft_in'
                      ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                >
                  ft / in
                </button>
                <button
                  type="button"
                  onClick={() => setActiveUnitTab('m')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                    activeUnitTab === 'm'
                      ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                >
                  meters
                </button>
              </div>
            </div>

            {/* Tab Inputs */}
            {activeUnitTab === 'cm' && (
              <div>
                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    min="10"
                    max="300"
                    value={cmInput}
                    onChange={(e) => handleCmChange(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 font-mono shadow-xs focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                  />
                  <span className="absolute right-3.5 top-2.5 text-xs font-medium text-slate-400">
                    centimeters
                  </span>
                </div>
              </div>
            )}

            {activeUnitTab === 'ft_in' && (
              <div className="grid grid-cols-2 gap-3">
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    max="9"
                    value={feetInput}
                    onChange={(e) => handleFeetInchesChange(e.target.value, inchesInput)}
                    className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 font-mono shadow-xs focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                  />
                  <span className="absolute right-3.5 top-2.5 text-xs font-medium text-slate-400">
                    feet
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    max="11.9"
                    value={inchesInput}
                    onChange={(e) => handleFeetInchesChange(feetInput, e.target.value)}
                    className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 font-mono shadow-xs focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                  />
                  <span className="absolute right-3.5 top-2.5 text-xs font-medium text-slate-400">
                    inches
                  </span>
                </div>
              </div>
            )}

            {activeUnitTab === 'm' && (
              <div>
                <div className="relative">
                  <input
                    type="number"
                    step="0.01"
                    min="0.2"
                    max="3.0"
                    value={mInput}
                    onChange={(e) => handleMChange(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 font-mono shadow-xs focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                  />
                  <span className="absolute right-3.5 top-2.5 text-xs font-medium text-slate-400">
                    meters
                  </span>
                </div>
              </div>
            )}

            {/* Validation Feedback */}
            {validationError && (
              <div className="flex items-center gap-2 text-xs font-medium text-rose-600 dark:text-rose-400">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{validationError}</span>
              </div>
            )}
            {validationWarning && (
              <div className="flex items-center gap-2 text-xs font-medium text-amber-600 dark:text-amber-400">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{validationWarning}</span>
              </div>
            )}
          </div>

          {/* Silhouette Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              Silhouette Style
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {GENDER_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setGenderStyle(opt.id)}
                  className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-center transition-all ${
                    genderStyle === opt.id
                      ? 'border-indigo-600 bg-indigo-50/70 text-indigo-700 ring-2 ring-indigo-500/20 dark:bg-indigo-950/40 dark:text-indigo-300'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
                  }`}
                >
                  <span className="text-xs font-bold">{opt.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Color Selection */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Silhouette Color
              </label>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-slate-500">{color}</span>
                <input
                  type="color"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="h-6 w-6 rounded border border-slate-300 cursor-pointer overflow-hidden dark:border-slate-700"
                />
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {COLOR_PALETTE.map((palColor) => (
                <button
                  key={palColor}
                  type="button"
                  onClick={() => setColor(palColor)}
                  style={{ backgroundColor: palColor }}
                  className={`h-7 w-7 rounded-lg transition-transform ${
                    color.toLowerCase() === palColor.toLowerCase()
                      ? 'scale-110 ring-2 ring-offset-2 ring-indigo-500'
                      : 'hover:scale-105'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Optional Transparent Image Upload */}
          <div className="border-t border-slate-200 pt-4 dark:border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Upload className="h-3.5 w-3.5 text-indigo-600" />
                Custom Image (Optional)
              </label>
              {customImageUrl && (
                <button
                  type="button"
                  onClick={() => setCustomImageUrl(undefined)}
                  className="text-xs text-rose-500 hover:underline"
                >
                  Remove Image
                </button>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">
              Upload a transparent PNG/WebP photo. It will scale proportionately and align to the ground baseline.
            </p>
            <input
              type="file"
              accept="image/png, image/webp, image/jpeg"
              onChange={handleImageUpload}
              className="text-xs text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-indigo-50 file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-indigo-700 hover:file:bg-indigo-100 dark:file:bg-indigo-950 dark:file:text-indigo-300 cursor-pointer"
            />
          </div>
        </form>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 border-t border-slate-200 px-6 py-4 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200/60 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 transition-colors"
          >
            <Check className="h-4 w-4" />
            {isEditing ? 'Save Changes' : 'Add to Chart'}
          </button>
        </div>
      </div>
    </div>
  );
};
