import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  ArrowUpDown, 
  TrendingUp, 
  TrendingDown, 
  Sparkles,
  ArrowRight,
  Calculator,
  Equal
} from 'lucide-react';
import { ComparisonSubject } from '../types';
import { 
  calculateComparisonStats, 
  calculatePairwiseDifference, 
  formatBothUnits 
} from '../utils/measurement';

interface ComparisonInsightsProps {
  subjects: ComparisonSubject[];
}

export const ComparisonInsights: React.FC<ComparisonInsightsProps> = ({ subjects }) => {
  const visibleSubjects = useMemo(() => {
    return subjects.filter((s) => s.isVisible && s.heightCm > 0);
  }, [subjects]);

  const stats = useMemo(() => {
    return calculateComparisonStats(visibleSubjects);
  }, [visibleSubjects]);

  // Pairwise selection state (Subject A vs Subject B)
  const [selectedAId, setSelectedAId] = useState<string>('');
  const [selectedBId, setSelectedBId] = useState<string>('');

  // Update pairwise selectors when subjects list changes
  React.useEffect(() => {
    if (visibleSubjects.length >= 2) {
      if (!selectedAId || !visibleSubjects.some((s) => s.id === selectedAId)) {
        setSelectedAId(visibleSubjects[0].id);
      }
      if (!selectedBId || !visibleSubjects.some((s) => s.id === selectedBId)) {
        setSelectedBId(visibleSubjects[1].id);
      }
    }
  }, [visibleSubjects, selectedAId, selectedBId]);

  const pairwiseResult = useMemo(() => {
    if (visibleSubjects.length < 2) return null;
    const a = visibleSubjects.find((s) => s.id === selectedAId);
    const b = visibleSubjects.find((s) => s.id === selectedBId);
    if (!a || !b) return null;
    return calculatePairwiseDifference(a, b);
  }, [visibleSubjects, selectedAId, selectedBId]);

  if (visibleSubjects.length === 0) {
    return null;
  }

  return (
    <section id="insights" className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-6">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400">
            <BarChart3 className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Smart Comparison Insights
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Statistical breakdown and head-to-head height differentials
            </p>
          </div>
        </div>
      </div>

      {/* Natural Language Summary Banner */}
      <div className="rounded-xl border border-indigo-100 bg-indigo-50/60 p-4 text-xs leading-relaxed text-indigo-950 dark:border-indigo-950/60 dark:bg-indigo-950/20 dark:text-indigo-200">
        <div className="flex items-start gap-2.5">
          <Sparkles className="h-4 w-4 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
          <div>
            {stats.count === 1 && stats.tallest ? (
              <span>
                Currently displaying <strong>{stats.tallest.name}</strong> measuring{' '}
                <strong>{formatBothUnits(stats.tallest.heightCm).combined}</strong>. Add at least one more subject to view comparative differences.
              </span>
            ) : stats.tallest && stats.shortest ? (
              <span>
                In this lineup of <strong>{stats.count} subjects</strong>,{' '}
                <strong>{stats.tallest.name}</strong> is the tallest at{' '}
                <strong>{formatBothUnits(stats.tallest.heightCm).combined}</strong>, while{' '}
                <strong>{stats.shortest.name}</strong> is the shortest at{' '}
                <strong>{formatBothUnits(stats.shortest.heightCm).combined}</strong>. The total height spread across the group is{' '}
                <strong>{formatBothUnits(stats.rangeCm).combined}</strong>, with a mean height of{' '}
                <strong>{formatBothUnits(stats.avgCm).combined}</strong>.
              </span>
            ) : null}
          </div>
        </div>
      </div>

      {/* Key Metric KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* Tallest */}
        <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-800/40">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
            <TrendingUp className="h-3.5 w-3.5 text-emerald-500" />
            <span>Tallest Subject</span>
          </div>
          <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
            {stats.tallest?.name || '—'}
          </div>
          <div className="text-xs font-mono font-medium text-emerald-600 dark:text-emerald-400 mt-0.5">
            {stats.tallest ? formatBothUnits(stats.tallest.heightCm).combined : '—'}
          </div>
        </div>

        {/* Shortest */}
        <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-800/40">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
            <TrendingDown className="h-3.5 w-3.5 text-amber-500" />
            <span>Shortest Subject</span>
          </div>
          <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
            {stats.shortest?.name || '—'}
          </div>
          <div className="text-xs font-mono font-medium text-amber-600 dark:text-amber-400 mt-0.5">
            {stats.shortest ? formatBothUnits(stats.shortest.heightCm).combined : '—'}
          </div>
        </div>

        {/* Group Average */}
        <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-800/40">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
            <Calculator className="h-3.5 w-3.5 text-indigo-500" />
            <span>Average Height</span>
          </div>
          <div className="text-sm font-bold text-slate-900 dark:text-white font-mono">
            {stats.avgCm > 0 ? `${stats.avgCm} cm` : '—'}
          </div>
          <div className="text-xs font-mono text-slate-500 dark:text-slate-400 mt-0.5">
            {stats.avgCm > 0 ? formatBothUnits(stats.avgCm).imperial : '—'}
          </div>
        </div>

        {/* Height Range */}
        <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5 dark:border-slate-800 dark:bg-slate-800/40">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-1">
            <ArrowUpDown className="h-3.5 w-3.5 text-sky-500" />
            <span>Total Spread</span>
          </div>
          <div className="text-sm font-bold text-slate-900 dark:text-white font-mono">
            {stats.rangeCm > 0 ? `${stats.rangeCm} cm` : '0 cm'}
          </div>
          <div className="text-xs font-mono text-slate-500 dark:text-slate-400 mt-0.5">
            {stats.rangeCm > 0 ? formatBothUnits(stats.rangeCm).imperial : `0' 0"`}
          </div>
        </div>
      </div>

      {/* Head-to-Head Pairwise Comparison Explorer */}
      {visibleSubjects.length >= 2 && pairwiseResult && (
        <div className="rounded-xl border border-slate-200 bg-slate-50/80 p-4.5 dark:border-slate-800 dark:bg-slate-800/50 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
              <Equal className="h-3.5 w-3.5 text-indigo-600" />
              Head-to-Head Pairwise Comparison
            </span>

            {/* Selectors */}
            <div className="flex items-center gap-2">
              <select
                value={selectedAId}
                onChange={(e) => setSelectedAId(e.target.value)}
                className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-800 shadow-2xs dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              >
                {visibleSubjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.heightCm}cm)
                  </option>
                ))}
              </select>

              <span className="text-xs font-bold text-slate-400">vs</span>

              <select
                value={selectedBId}
                onChange={(e) => setSelectedBId(e.target.value)}
                className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-800 shadow-2xs dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              >
                {visibleSubjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.heightCm}cm)
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Pairwise Diff Result Card */}
          <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900 shadow-2xs">
            {pairwiseResult.diffCm === 0 ? (
              <p className="text-xs font-medium text-slate-600 dark:text-slate-300">
                Both <strong>{pairwiseResult.tallerSubject.name}</strong> and{' '}
                <strong>{pairwiseResult.shorterSubject.name}</strong> have the exact same height (
                {formatBothUnits(pairwiseResult.tallerSubject.heightCm).combined}).
              </p>
            ) : (
              <div className="space-y-3">
                <div className="flex items-baseline gap-2">
                  <span className="text-lg font-bold text-indigo-600 dark:text-indigo-400 font-mono">
                    +{pairwiseResult.diffCm} cm
                  </span>
                  <span className="text-xs font-mono text-slate-500">
                    (+{pairwiseResult.diffInches}&quot; / {pairwiseResult.diffFeetIn})
                  </span>
                  <span className="text-xs text-slate-400">·</span>
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    {pairwiseResult.ratio}× ratio ({pairwiseResult.percentDiff}% taller)
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-normal">
                  <strong>{pairwiseResult.tallerSubject.name}</strong> ({formatBothUnits(pairwiseResult.tallerSubject.heightCm).combined}) is{' '}
                  <strong>{pairwiseResult.diffCm} cm ({pairwiseResult.diffInches}&quot;)</strong> taller than{' '}
                  <strong>{pairwiseResult.shorterSubject.name}</strong> ({formatBothUnits(pairwiseResult.shorterSubject.heightCm).combined}).
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Comparison Data Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-slate-200 text-slate-400 dark:border-slate-800">
              <th className="pb-2 font-semibold">Rank</th>
              <th className="pb-2 font-semibold">Subject</th>
              <th className="pb-2 font-semibold">Category</th>
              <th className="pb-2 font-semibold font-mono">Metric</th>
              <th className="pb-2 font-semibold font-mono">Imperial</th>
              <th className="pb-2 font-semibold">Difference from Tallest</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-slate-700 dark:text-slate-300">
            {[...visibleSubjects]
              .sort((a, b) => b.heightCm - a.heightCm)
              .map((subject, idx) => {
                const both = formatBothUnits(subject.heightCm);
                const diffFromTallest = stats.tallest 
                  ? Number((stats.tallest.heightCm - subject.heightCm).toFixed(1)) 
                  : 0;

                return (
                  <tr key={subject.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-2.5 font-bold font-mono text-slate-400">{idx + 1}</td>
                    <td className="py-2.5">
                      <div className="flex items-center gap-2">
                        <span
                          className="h-2.5 w-2.5 rounded-full shrink-0"
                          style={{ backgroundColor: subject.color }}
                        />
                        <span className="font-semibold text-slate-900 dark:text-white">
                          {subject.name}
                        </span>
                      </div>
                    </td>
                    <td className="py-2.5 capitalize text-slate-500">{subject.category}</td>
                    <td className="py-2.5 font-mono font-medium">{both.metric}</td>
                    <td className="py-2.5 font-mono text-slate-500 dark:text-slate-400">{both.imperial}</td>
                    <td className="py-2.5 font-mono text-slate-500">
                      {diffFromTallest === 0 ? (
                        <span className="font-semibold text-emerald-600 dark:text-emerald-400">Baseline (Tallest)</span>
                      ) : (
                        `-${diffFromTallest} cm (-${(diffFromTallest / 2.54).toFixed(1)}")`
                      )}
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </div>
    </section>
  );
};
