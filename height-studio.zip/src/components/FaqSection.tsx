import React, { useState } from 'react';
import { HelpCircle, ChevronDown } from 'lucide-react';

interface FaqItem {
  q: string;
  a: string;
}

const FAQS: FaqItem[] = [
  {
    q: 'How accurate are the proportional figures in Height Studio?',
    a: 'Height Studio uses exact mathematical scaling anchored to a shared 0.0 cm ground baseline. All figures adhere strictly to an orthographic vertical pixel-per-centimeter ratio with no perspective distortions or foreshortening. 1 inch is converted at exactly 2.54 cm, and 1 foot at 30.48 cm.',
  },
  {
    q: 'Can I upload custom transparent images or photos?',
    a: 'Yes. In the "Add Person" panel, you can upload any transparent PNG, WebP, or JPEG photo. The studio automatically anchors the bottom boundary of the image to the ground baseline and scales its total vertical height to your specified measurement without distortion.',
  },
  {
    q: 'How does URL sharing work without an external server or account?',
    a: 'Your entire comparison lineup—including heights, silhouette styles, custom colors, and categories—is compressed into a URL-safe hash. When someone opens your shared link, the application reconstitutes the exact state locally in their browser without sending your data to external servers.',
  },
  {
    q: 'How do I switch between Metric (centimeters) and Imperial (feet & inches)?',
    a: 'You can toggle the ruler between Dual (showing both cm and ft/in simultaneously), Metric only, or Imperial only using the ruler toolbar button directly above the canvas. When entering heights, all fields automatically stay synchronized in real time.',
  },
  {
    q: 'Where do celebrity, athlete, and character heights come from?',
    a: 'All factual figures in our preset library cite official combines (e.g. NBA Draft Combine, Olympic rosters), verified medical measurements (e.g. Guinness World Records for Robert Wadlow and Chandra Dangi), or verified historical autopsy records. Fictional characters are referenced directly from canonical studio sourcebooks.',
  },
  {
    q: 'What is the tallest and shortest figure I can compare?',
    a: 'Height Studio supports measurements from 5 cm (small animals or miniature objects) up to 100,000 cm (1,000-meter skyscrapers like the Burj Khalifa). The vertical ruler and canvas ceiling automatically adapt smoothly based on the tallest active figure in your lineup.',
  },
  {
    q: 'How can I save or download my comparison for a presentation?',
    a: 'Click the "Export Chart" button in the top navigation bar. You can instantly download a crisp 2x resolution PNG with full ruler markings, print a clean presentation sheet, copy formatted text to your clipboard, or save the lineup into your browser\'s local storage.',
  },
];

export const FaqSection: React.FC = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIdx(openIdx === idx ? null : idx);
  };

  return (
    <section id="faq" className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400">
            <HelpCircle className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Frequently Asked Questions
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Common questions about accuracy, units, image uploads, and exports
            </p>
          </div>
        </div>
      </div>

      <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
        {FAQS.map((faq, idx) => {
          const isOpen = openIdx === idx;

          return (
            <div key={idx} className="py-3.5">
              <button
                onClick={() => toggle(idx)}
                className="flex w-full items-center justify-between text-left gap-4 group"
              >
                <span className="text-xs sm:text-sm font-semibold text-slate-900 group-hover:text-indigo-600 dark:text-slate-100 dark:group-hover:text-indigo-400 transition-colors">
                  {faq.q}
                </span>
                <ChevronDown
                  className={`h-4 w-4 shrink-0 text-slate-400 transition-transform duration-200 ${
                    isOpen ? 'rotate-180 text-indigo-600 dark:text-indigo-400' : ''
                  }`}
                />
              </button>
              {isOpen && (
                <div className="mt-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed pr-6 animate-in fade-in duration-150">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
